# WANDER Tour site

## Run locally

From the core folder (the folder containing manage.py):

```sh
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

Open http://127.0.0.1:8000/.

## Fixes

- Fixed login authentication typo and registration template syntax.
- Removed conflicting browser-only authentication; Django manages accounts and sessions.
- Fixed post-registration navigation and validated local login redirects.
- Added Django password/email validation and duplicate-account handling.
- Protected account page and displayed server feedback.
- Corrected static/media paths and connected the custom 404 handler.
- Validated contact submissions and added success feedback.
- Escaped browser booking data before rendering it in the account page.

Bookings remain browser-local requests, as in the supplied project. They are not sent to a travel operator. Newsletter signup remains a frontend demonstration.

Run regression checks with `python manage.py test`.
