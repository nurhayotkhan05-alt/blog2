from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from .models import Contact
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from django.contrib.auth.password_validation import validate_password
from django.utils.http import url_has_allowed_host_and_scheme
from django.db import IntegrityError


def home(request):
    return render(request, 'index.html')


def destinations(request):
    return render(request, 'destinations.html')


def destination_detail(request):
    return render(request, 'destination-detail.html')


def packages(request):
    return render(request, 'packages.html')


def package_detail(request):
    return render(request, 'package-detail.html')


def blog(request):
    return render(request, 'blog.html')


def blog_detail(request):
    return render(request, 'blog-detail.html')


def about(request):
    return render(request, 'about.html')



def faq(request):
    return render(request, 'faq.html')




@login_required
def profile(request):
    return render(request, 'profile.html')



def booking(request):
    return render(request, 'booking.html')


def page_404(request):
    return render(request, '404.html', status=404)


def custom_404(request, exception):
    return render(request, '404.html', status=404)


def contact(request):
    if request.method == "POST":
        name = request.POST.get('name', '').strip()
        email = request.POST.get('email', '').strip()
        message = request.POST.get('message', '').strip()
        try:
            validate_email(email)
            if not name or len(name) > 100 or not message:
                raise ValidationError('Please enter a name (up to 100 characters) and message.')
        except ValidationError as error:
            messages.error(request, ' '.join(error.messages))
            return render(request, 'contact.html', status=400)

        Contact.objects.create(
            name=name,
            email=email,
            message=message,
        )
        messages.success(request, 'Thank you! Your message has been sent.')
        return redirect('contact')
    
    return render(request,'contact.html')




def register(request):
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        email = request.POST.get('email', '').strip().lower()
        password = request.POST.get('password', '')
        confirm_password = request.POST.get('confirm_password', '')

        # Barcha maydonlarni tekshirish
        if not name or not email or not password or not confirm_password:
            messages.error(request, 'Sabhi fields bhariye!')
            return redirect('register')

        # Parollarni tekshirish
        if password != confirm_password:
            messages.error(request, 'Passwords match nahi karte!')
            return redirect('register')

        try:
            validate_email(email)
            if len(email) > 150 or len(name) > 150:
                raise ValidationError('Name or email is too long (maximum 150 characters).')
            validate_password(password, User(username=email, email=email, first_name=name))
        except ValidationError as error:
            messages.error(request, ' '.join(error.messages))
            return redirect('register')

        # Email mavjudligini tekshirish
        if User.objects.filter(email__iexact=email).exists() or User.objects.filter(username__iexact=email).exists():
            messages.error(request, 'Is email se user pehle se maujood hai!')
            return redirect('register')

        # Foydalanuvchini yaratish
        try:
            user = User.objects.create_user(
                username=email, email=email, password=password, first_name=name
            )
        except IntegrityError:
            messages.error(request, 'This account already exists.')
            return redirect('register')

        # Tizimga kiritish
        login(request, user)

        messages.success(
            request,
            'Registration successful!'
        )

        return redirect('home')

    return render(request, 'register.html')


def login_view(request):
    if request.user.is_authenticated:
        return redirect('home')
    if request.method == 'POST':
        email = request.POST.get('email','').strip().lower()
        password = request.POST.get('password','')

        user = authenticate(request,username=email,password=password)

        if user is not None:
            login(request, user)
            messages.success(request,'Login successfull')
            next_url = request.POST.get('next') or request.GET.get('next')

            if next_url and url_has_allowed_host_and_scheme(
                next_url, allowed_hosts={request.get_host()}, require_https=request.is_secure()
            ):
                return redirect(next_url)

            return redirect('home')

        messages.error(request,'Email yaa password galaat hai')
        return redirect('login')
    return render(request, 'login.html')




def logout_view(request):
    logout(request)

    messages.success(request,'aap log out hai')
    return redirect('home')


