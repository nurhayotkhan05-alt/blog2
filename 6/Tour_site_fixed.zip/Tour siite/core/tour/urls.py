from django.urls import path

from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('destinations/', views.destinations, name='destinations'),
    path('destinations/detail/', views.destination_detail, name='destination_detail'),
    path('packages/', views.packages, name='packages'),
    path('packages/detail/', views.package_detail, name='package_detail'),
    path('blog/', views.blog, name='blog'),
    path('blog/detail/', views.blog_detail, name='blog_detail'),
    path('about/', views.about, name='about'),
    path('contact/', views.contact, name='contact'),
    path('faq/', views.faq, name='faq'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register, name='register'),
    path('profile/', views.profile, name='profile'),
    path('logout/', views.logout_view, name='logout'),
    path('booking/', views.booking, name='booking'),
    path('404/', views.page_404, name='page_404'),
]
