from django.test import TestCase, override_settings
from django.contrib.auth.models import User
from django.urls import reverse
from .models import Contact


class SiteTests(TestCase):
    def test_public_pages(self):
        for name in ('home', 'destinations', 'destination_detail', 'packages',
                     'package_detail', 'blog', 'blog_detail', 'about', 'contact',
                     'faq', 'login', 'register', 'booking'):
            with self.subTest(page=name):
                self.assertEqual(self.client.get(reverse(name)).status_code, 200)

    def test_account_requires_login(self):
        self.assertRedirects(self.client.get(reverse('profile')), '/login/?next=/profile/')

    def test_register_login_logout(self):
        response = self.client.post(reverse('register'), {
            'name': 'Traveler', 'email': 'traveler@example.com',
            'password': 'Travel!Kite992', 'confirm_password': 'Travel!Kite992'})
        self.assertRedirects(response, reverse('home'))
        user = User.objects.get(email='traveler@example.com')
        self.assertTrue(user.check_password('Travel!Kite992'))
        self.assertContains(self.client.get(reverse('profile')), 'data-authenticated="true"')
        self.client.get(reverse('logout'))
        self.assertNotIn('_auth_user_id', self.client.session)
        response = self.client.post(reverse('login')+'?next=/profile/', {
            'email': 'TRAVELER@example.com', 'password': 'Travel!Kite992'})
        self.assertRedirects(response, reverse('profile'))

    def test_bad_login_and_external_redirect(self):
        User.objects.create_user('traveler@example.com', password='Travel!Kite992')
        self.assertRedirects(self.client.post(reverse('login'), {
            'email': 'traveler@example.com', 'password': 'wrong'}), reverse('login'))
        response = self.client.post(reverse('login')+'?next=https://example.com/', {
            'email': 'traveler@example.com', 'password': 'Travel!Kite992'})
        self.assertRedirects(response, reverse('home'))

    def test_registration_validation(self):
        data = {'name': 'Traveler', 'email': 'invalid', 'password': 'Travel!Kite992',
                'confirm_password': 'Travel!Kite992'}
        self.client.post(reverse('register'), data)
        self.assertEqual(User.objects.count(), 0)
        data.update(email='traveler@example.com', password='12345678', confirm_password='12345678')
        self.client.post(reverse('register'), data)
        self.assertEqual(User.objects.count(), 0)
        data.update(password='Travel!Kite992', confirm_password='different')
        self.client.post(reverse('register'), data)
        self.assertEqual(User.objects.count(), 0)
        data['confirm_password'] = data['password']
        self.client.post(reverse('register'), data)
        self.client.logout()
        self.client.post(reverse('register'), data)
        self.assertEqual(User.objects.count(), 1)

    def test_contact_validation_and_success(self):
        self.assertEqual(self.client.post(reverse('contact'), {}).status_code, 400)
        self.assertEqual(Contact.objects.count(), 0)
        response = self.client.post(reverse('contact'), {
            'name': 'Traveler', 'email': 'traveler@example.com', 'message': 'Hello'})
        self.assertRedirects(response, reverse('contact'))
        self.assertEqual(Contact.objects.count(), 1)

    @override_settings(DEBUG=False)
    def test_custom_404(self):
        response = self.client.get('/missing-page/')
        self.assertEqual(response.status_code, 404)
        self.assertTemplateUsed(response, '404.html')
