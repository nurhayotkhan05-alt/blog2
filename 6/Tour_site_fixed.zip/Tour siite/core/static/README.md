# WANDER — Multi-page Travel Website

A complete responsive travel frontend based on the supplied visual reference.

## Included pages
- `index.html` — Home
- `destinations.html` — Destination catalog + filters/search
- `destination-detail.html` — Destination detail
- `packages.html` — Tour package catalog + filters/search
- `package-detail.html` — Package detail
- `booking.html` — Booking form
- `blog.html` — Blog list
- `blog-detail.html` — Article page
- `about.html` — About page
- `contact.html` — Contact form
- `faq.html` — FAQ accordion
- `login.html` — Login
- `register.html` — Register
- `profile.html` — User account + bookings
- `logout.html` — Logout
- `404.html` — Error page

## Stack
- HTML5
- Tailwind CSS (CDN utility layer)
- Custom CSS
- Sass source (`assets/scss/style.scss`)
- Vanilla JavaScript
- Local JPG assets

## Demo functionality
- Responsive desktop/tablet/mobile navigation
- Login / register / logout using browser `localStorage`
- My Account screen
- Booking requests saved for the current demo user
- Destination/package search + filters
- Home destination carousel
- FAQ accordion
- Contact/newsletter demo interactions
- Scroll reveal and animated statistics

> Security note: localStorage auth is only for frontend demonstration. A production project should use Django or another backend with hashed passwords, sessions, CSRF protection, validation and a database.

## Run
You can open `index.html` directly, but using a local server is recommended:

```bash
python -m http.server 8000
```

Open: `http://localhost:8000`

## Sass
```bash
npm install
npm run sass
```

## Tailwind local build (optional)
The HTML already works with the Tailwind CDN. A local Tailwind setup is included for future development.
