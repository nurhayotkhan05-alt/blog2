const appUrls=window.WANDER_URLS||{home:'/',destinations:'/destinations/',login:'/login/',register:'/register/',profile:'/profile/',logout:'/logout/',booking:'/booking/'};

const $ = (s, p=document) => p.querySelector(s);
const $$ = (s, p=document) => [...p.querySelectorAll(s)];
const store = {
  get(k, fallback=null){ try{return JSON.parse(localStorage.getItem(k)) ?? fallback}catch{return fallback}},
  set(k,v){ localStorage.setItem(k,JSON.stringify(v)) },
  del(k){ localStorage.removeItem(k) }
};
function toast(msg){ const el=$('#toast'); if(!el)return; el.textContent=msg; el.classList.add('show'); clearTimeout(window.__toast); window.__toast=setTimeout(()=>el.classList.remove('show'),2600); }
function currentUser(){
  const d=document.body.dataset;
  return d.authenticated==='true'?{id:Number(d.userId),name:d.userName,email:d.userEmail}:null;
}
function initials(name='Traveler'){ return name.split(' ').map(x=>x[0]).join('').slice(0,2).toUpperCase(); }
function updateAuthUI(){
  const user=currentUser();
  $$('.auth-guest').forEach(el=>el.classList.toggle('hidden',!!user));
  $$('.auth-user').forEach(el=>el.classList.toggle('hidden',!user));
  $$('.user-initials').forEach(el=>el.textContent=initials(user?.name));
  $$('.user-name').forEach(el=>el.textContent=user?.name||'Traveler');
  $$('.user-email').forEach(el=>el.textContent=user?.email||'');
}
function pageName(){ return document.body.dataset.page || ''; }
function setupNav(){
  const btn=$('#menuButton'), menu=$('#mobileMenu');
  btn?.addEventListener('click',()=>{ const open=menu.classList.toggle('open'); btn.setAttribute('aria-expanded',String(open)); });
  $$('#mobileMenu a').forEach(a=>a.addEventListener('click',()=>menu?.classList.remove('open')));
  $$(`[data-nav="${pageName()}"]`).forEach(a=>a.classList.add('active'));
}
function setupReveal(){ if(!('IntersectionObserver'in window)){ $$('.reveal').forEach(x=>x.classList.add('is-visible')); return;} const ob=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)e.target.classList.add('is-visible')}),{threshold:.1}); $$('.reveal').forEach(x=>ob.observe(x)); }
function setupCounts(){ const items=$$('[data-count]'); if(!items.length)return; const ob=new IntersectionObserver((es,o)=>es.forEach(e=>{if(!e.isIntersecting)return; const el=e.target,t=Number(el.dataset.count),start=performance.now(); const tick=n=>{const p=Math.min((n-start)/850,1),v=Math.round(t*(1-Math.pow(1-p,3))); el.textContent=t>=1000?`${Math.round(v/1000)}k+`:`${v}${t===10?'yrs':'+'}`; if(p<1)requestAnimationFrame(tick)}; requestAnimationFrame(tick);o.unobserve(el)}),{threshold:.5});items.forEach(i=>ob.observe(i)); }
function setupCarousel(){ const track=$('#destinationTrack'); if(!track)return; let idx=0; const visible=()=>innerWidth<768?1:innerWidth<1024?2:4; const step=()=>{const c=$('.destination-card',track);return c?c.getBoundingClientRect().width+16:0}; const update=()=>{idx=Math.max(0,Math.min(idx,track.children.length-visible()));track.style.transform=`translateX(-${idx*step()}px)`}; $('#destPrev')?.addEventListener('click',()=>{idx--;update()});$('#destNext')?.addEventListener('click',()=>{idx++;update()});addEventListener('resize',update); }
function setupFilters(){
  const cards=$$('[data-filter-card]'), input=$('#catalogSearch'), chips=$$('[data-filter-chip]'); if(!cards.length)return; let cat='all';
  const run=()=>{const q=(input?.value||'').toLowerCase().trim(); let count=0; cards.forEach(c=>{const ok=(cat==='all'||c.dataset.category===cat)&&(!q||c.dataset.search.toLowerCase().includes(q)); c.classList.toggle('hidden',!ok); if(ok)count++;}); $('#emptyState')?.classList.toggle('hidden',count!==0)};
  input?.addEventListener('input',run); chips.forEach(ch=>ch.addEventListener('click',()=>{chips.forEach(x=>x.classList.remove('active'));ch.classList.add('active');cat=ch.dataset.filterChip;run()}));
}
function setupPasswords(){ $$('.password-toggle').forEach(btn=>btn.addEventListener('click',()=>{const input=btn.parentElement.querySelector('input');input.type=input.type==='password'?'text':'password';btn.textContent=input.type==='password'?'Show':'Hide'})); }
function setupBooking(){ const form=$('#bookingForm'); if(!form)return; const d=new URLSearchParams(location.search).get('destination'); if(d&&$('#destination'))$('#destination').value=d; form.addEventListener('submit',e=>{e.preventDefault(); const user=currentUser(),msg=$('#bookingMessage'); if(!user){msg.textContent='Please log in before confirming a booking.';msg.className='form-message error'; setTimeout(()=>location.href=appUrls.login+'?next='+encodeURIComponent(appUrls.booking),900);return} const fd=new FormData(form); const item={id:'WN'+Date.now().toString().slice(-7),userId:user.id,destination:fd.get('destination'),date:fd.get('date'),travelers:fd.get('travelers'),package:fd.get('package'),status:'Pending',created:new Date().toISOString()}; const all=store.get('wander_bookings',[]);all.unshift(item);store.set('wander_bookings',all);msg.textContent=`Booking ${item.id} saved. You can see it in My Account.`;msg.className='form-message success';form.reset();}); }
function escapeHTML(value){return String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function escapeHTML(value){return String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function setupProfile(){ if(pageName()!=='profile')return; const user=currentUser(); if(!user){location.href=appUrls.login+'?next='+encodeURIComponent(appUrls.profile);return} updateAuthUI(); const all=store.get('wander_bookings',[]).filter(b=>b.userId===user.id),list=$('#bookingList'); $('#profileJoined').textContent='Active traveler account'; if(!all.length){list.innerHTML=`<div class="empty-state">No bookings yet. <a href="${appUrls.booking}"><b>Plan your first trip →</b></a></div>`;return} list.innerHTML=all.map(b=>`<div class="booking-item"><div><h4>${escapeHTML(b.destination)}</h4><p>${escapeHTML(b.package)} · ${escapeHTML(b.travelers)} traveler(s) · ${new Date(b.date+'T00:00:00').toLocaleDateString()}</p><p>Reference: ${escapeHTML(b.id)}</p></div><span class="badge pending">${escapeHTML(b.status)}</span></div>`).join(''); }
function setupContact(){ const f=$('#contactForm'); f?.addEventListener('submit',e=>{e.preventDefault(); $('#contactMessage').textContent='Thanks! Your message has been recorded in this frontend demo.';$('#contactMessage').className='form-message success';f.reset()}); }
function setupNewsletter(){ $$('.newsletter').forEach(f=>f.addEventListener('submit',e=>{e.preventDefault();toast('Thanks — you are on the travel list!');f.reset()})); }
function setupFAQ(){ $$('.faq-q').forEach(b=>b.addEventListener('click',()=>b.closest('.faq-item').classList.toggle('open'))); }
function setupDestinationSearchHome(){ const input=$('#searchInput'); if(!input)return; input.addEventListener('keydown',e=>{if(e.key==='Enter'){const q=input.value.trim();location.href=appUrls.destinations+(q?`?q=${encodeURIComponent(q)}`:'')}}); }
function prefillCatalogQuery(){ const q=new URLSearchParams(location.search).get('q'); if(q&&$('#catalogSearch')){$('#catalogSearch').value=q;$('#catalogSearch').dispatchEvent(new Event('input'));} }
document.addEventListener('DOMContentLoaded',()=>{store.del('wander_users');store.del('wander_current_user');store.del('wander_users');store.del('wander_current_user');setupNav();updateAuthUI();setupReveal();setupCounts();setupCarousel();setupFilters();setupPasswords();setupBooking();setupProfile();setupContact();setupNewsletter();setupFAQ();setupDestinationSearchHome();prefillCatalogQuery();$$('[data-year]').forEach(x=>x.textContent=new Date().getFullYear());});
