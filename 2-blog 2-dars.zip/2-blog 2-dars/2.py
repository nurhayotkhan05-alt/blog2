try:
    a = int(input("a = "))
    b = int(input("b = "))
    c = a / b
    print(c)
except ZeroDivisionError:
    print("Sonni no'lga bo'lish mumkin emas!")
except ValueError:
    print("Faqat son kiriting!")