raja_shivaji = {
    "Salman Khan" : "Jeeva Mahala",
    "Sanjay Dutt" : "Afzal Khan",
    "Riteish Deshmukh" : "Raja Shivaji",
    "Genelia Deshmukh" : "Saibai"
}


k = input("Aktyorni ismini kiriting: ").title()

try:
    print(f"{k} o'ynagan ro'l {raja_shivaji[k]}")
except KeyError:
    print(f"{k} bo'yicha ma'lumot yo'q")