try:
    son = int(input("Son kiriting: "))
except:
    print("Faqat son kiriting!")