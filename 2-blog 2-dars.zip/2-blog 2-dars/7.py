while True:

    try:
        yosh = int(input("Yosh kiriting: "))
        print(f"Sizning yoshingiz: {yosh}")
        break
    except:
        print("Yosh kiritish kere")
        continue