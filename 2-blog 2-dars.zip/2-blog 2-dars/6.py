file = input("Fayl nomini kiriting: ")

try:
    with open(file,"r",encoding="utf-8") as f:
        r = f.read()
        print(r)

except FileNotFoundError:
    print("Bunday nomli fayl topilmadi!")