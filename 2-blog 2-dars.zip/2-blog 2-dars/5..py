try:
    son = input("Son kiriting: ")
    print(int(son))
except ValueError:
    print("Songa aylantirolmayman!")