raja_shivaji = ['Riteish Deshmukh','Genelia Deshmukh','Salman Khan','Sanjay Dutt']
index = int(input("Indexni kiriting: "))

try:
    print(f"{raja_shivaji[index]} listdan topildi!")

except IndexError:
    print(f"topilmadi!")
